some definition! 
[Google](www.google.de)